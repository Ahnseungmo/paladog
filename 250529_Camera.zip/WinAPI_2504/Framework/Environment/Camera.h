#pragma once

class Camera : public Transform
{
public:
	Camera();
	~Camera();

	void Update();

private:
	void FreeMode();

private:
	float speed = 300.0f;
	Matrix view;

	MatrixBuffer* viewBuffer;	
};